'use strict';

const { start } = require('./src/server');

start();
